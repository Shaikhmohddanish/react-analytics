"use client"

import React from "react"

const TestComponent = () => {
  return <div>Test Component</div>
}

export default TestComponent
